# CivicSense AI — Accessibility Upgrade (WCAG 2.2 AA)

An accessibility overhaul modifying the existing CivicSense platform to empower blind and visually impaired citizens, featuring Web Speech API integration (**VoiceAssist**), voice-guided hazard reporting, audio hazard readers, an accessible nearby hazards alternative to maps, configurable high-contrast/text scaling, and proximity alerts with audio chimes.

## User Review & Critical Decisions

> [!IMPORTANT]
> The following user preferences were confirmed during the interactive clarification interview:
> - **VoiceAssist Placement**: Persistent floating voice button with expandable accessible dock at the bottom of the viewport.
> - **Hazard Proximity Warnings**: Gentle audio chime followed by spoken announcement when approaching a reported hazard (with explicit opt-in, strict cooldowns, and safety disclaimers).
> - **Display Controls**: Accessibility panel with instant toggles for High Contrast Mode, Large Text scaling, and Motion Reduction.

- **Confirmed Decision 1**: Implement **VoiceAssist** using the native Web Speech API (`SpeechRecognition` / `webkitSpeechRecognition` and `window.speechSynthesis`) with zero paid external APIs.
- **Confirmed Decision 2**: Provide a keyboard-accessible text alternative directly within the voice dock for users with microphone constraints or speech differences.
- **Confirmed Decision 3**: Preserve 100% of the existing CivicSense architecture, design, Google Maps integration, Gemini AI vision endpoints, and municipal triage pipelines while layering full accessibility compliance.

---

### 1. Overview & Core Concept

- **What It Does**: Transforms CivicSense into an inclusive civic engagement platform where blind, visually impaired, and motor-impaired users can independently discover, inspect, and report municipal infrastructure hazards through speech, keyboard navigation, and screen-reader optimizations.
- **Target Audience**: Blind and low-vision citizens, users relying on Android TalkBack or desktop screen readers (NVDA, JAWS, VoiceOver), keyboard-only navigators, and municipal workers needing hands-free reporting.
- **Key Value**: Democratizes civic safety reporting without requiring sight of visual maps or photo viewfinders, strictly upholding WCAG 2.2 Level AA.

---

### 2. User Experience & Visual Design

#### A. VoiceAssist Floating Button & Expandable Dock
- **Persistent Voice Action Button**: Positioned in the bottom-right viewport (respecting the 15% mobile sticky budget). Features clear ARIA labeling (`aria-label="CivicSense Voice Assistant"`), distinct focus ring, and speech state indicators (Listening, Speaking, Idle).
- **Expandable Accessible Dock**:
  - Live transcript display of both spoken input and assistant synthesized responses.
  - Interactive controls: *Start Listening*, *Stop / Silence*, *Repeat Last Message*, and a text input field for manual typed commands.
  - Guided reporting step tracker: Step 1 (Hazard Type) $\rightarrow$ Step 2 (Description) $\rightarrow$ Step 3 (Location) $\rightarrow$ Step 4 (Confirm Submission).

#### B. Accessibility Panel & Display Controls
- **Accessible Top-Bar Trigger**: Placed alongside the theme toggle with an `Eye` / `Accessibility` icon and label (`aria-label="Accessibility Settings"`).
- **Control Modals / Drawer**:
  - **High-Contrast Mode**: Pure black/white contrast ratios ($>7:1$), vivid yellow/cyan accents, and reinforced borders.
  - **Large Text Mode**: Upscales root body text and line height without breaking layout geometry or clipping text.
  - **Reduced Motion**: Respects `prefers-reduced-motion` and adds a manual toggle to disable pulsing map markers, toast animations, and card reveals.
  - **Location Hazard Proximity Warning**: Opt-in toggle with configurable distance threshold (50m, 100m, 200m).

#### C. Accessible Nearby Hazards List (Map Alternative)
- **Tabbed / Toggleable Map View**: A prominent toggle on the Map page: `[Interactive Map View | Accessible List View]`.
- **Structured Card & Table List**:
  - Distance badge with straight-line proximity (e.g. `120 meters away`).
  - Clear semantic badges distinguishing *Community Verified* from *Unverified Reports*.
  - Sort controls: *Sort by Proximity (Nearest First)* and *Sort by Severity (Critical First)*.
  - Action buttons: *Read Aloud*, *View Lifecycle Timeline*, and *Confirm / Upvote*.

#### D. Audio Descriptions on Hazard Cards & Detail Modal
- **Direct Speech Controls**: Every hazard card and the `HazardDetailsModal` includes a *Listen to Hazard Summary* button.
- Reads category, location address, severity level, current status, verified updates, and AI image findings in clear, natural prose.
- Includes a dedicated *Stop Speech* button that immediately aborts `speechSynthesis`.

---

### 3. Key Product Decisions & Trade-Offs

- **Web Speech API vs. External Paid Cloud Speech**:
  - *Chosen Approach*: Native Web Speech API (`SpeechRecognition` / `webkitSpeechRecognition` and `speechSynthesis`).
  - *Why*: Instant client-side latency, zero API costs, zero external token dependencies, and total privacy for the user's microphone stream.
  - *Graceful Fallback*: If the browser lacks speech recognition support (e.g. Firefox), the dock displays a friendly notice and immediately provides the typed command alternative with full speech synthesis output.

- **Audio Proximity Warning Architecture**:
  - *Chosen Approach*: Web Audio API synthesized soft two-tone harmonic chime (`440Hz -> 880Hz`) followed by concise spoken announcement.
  - *Cooldown System*: 10-minute deduplication window per hazard ID to avoid repeated audio spamming while walking near an incident.
  - *Safety Disclaimer*: Explicit audio and visual disclaimer: *"GPS distance is approximate straight-line estimation. CivicSense is not a replacement for a cane, guide dog, or mobility orientation."*

- **AI Image Alternative Text**:
  - *Chosen Approach*: Synthesize `aiClassification.categoryDetected` + `aiClassification.identifiedAttributes` + `aiClassification.impactReason` into structured `alt` text and readable descriptions.
  - *Distinction*: Explicitly labels AI confidence and marks AI vision predictions separately from municipal inspector verification notes.

---

### 4. Technical Architecture & System Integration

```
┌────────────────────────────────────────────────────────────────────────┐
│                        CivicSense Voice & A11y                         │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │
           ┌────────────────────────┴────────────────────────┐
           ▼                                                 ▼
┌─────────────────────────────┐           ┌──────────────────────────────┐
│  Accessibility Context      │           │    VoiceAssist Engine        │
│  • High Contrast Mode       │           │  • SpeechRecognition (Web)   │
│  • Large Text Scaling       │◄─────────►│  • SpeechSynthesis (TTS)     │
│  • Reduced Motion state     │           │  • Web Audio Chime Generator │
│  • Proximity Warning Watcher│           │  • Guided Report State Mach. │
└─────────────────────────────┘           └──────────────────────────────┘
           │                                                 │
           ▼                                                 ▼
┌─────────────────────────────┐           ┌──────────────────────────────┐
│    UI & Screen Readers      │           │      Existing Core           │
│  • VoiceAssistDock.tsx      │           │  • CivicContext              │
│  • AccessibleNearbyList.tsx │◄─────────►│  • /api/analyze-hazard       │
│  • AccessibilityModal.tsx   │           │  • HazardDetailsModal.tsx    │
│  • Global ARIA Live Regions │           │  • ReportHazardView.tsx      │
└─────────────────────────────┘           └──────────────────────────────┘
```

#### New Files & Components Planned:
1. `src/context/AccessibilityContext.tsx`: Manages high-contrast, large-text, motion, audio-chime preferences, GPS proximity alerts, and global announcements.
2. `src/utils/audioAlerts.ts`: Web Audio API synthetic chime generator (harmonic bell) and speech synthesis wrapper with mute/stop controls.
3. `src/components/VoiceAssistDock.tsx`: Floating accessible microphone button, expandable voice dock, speech transcript, guided reporting state machine, and keyboard input alternative.
4. `src/components/AccessibilityModal.tsx`: Accessible settings dialog with contrast, text size, and proximity alert controls.
5. `src/components/AccessibleNearbyList.tsx`: Fully accessible list alternative to Google Map with distance sorting, filter chips, and audio reader controls.
6. `src/components/AriaLiveAnnouncer.tsx`: Invisible polite and assertive ARIA live regions for screen-reader announcements.

#### Existing Files to Upgrade:
- `src/App.tsx`: Mount `AccessibilityProvider`, `VoiceAssistDock`, `AccessibilityModal`, and `AriaLiveAnnouncer`.
- `src/components/Navbar.tsx`: Add Accessibility settings button, skip-to-main-content link, and ensure proper ARIA attributes.
- `src/views/MapView.tsx`: Embed the Accessible List View switcher so blind users can toggle directly to `AccessibleNearbyList`.
- `src/views/HazardDetailsModal.tsx`: Add "Read Details Aloud" button, accessible dialog attributes (`role="dialog"`, `aria-modal="true"`, focus trap), and descriptive image alt-text.
- `src/views/ReportHazardView.tsx`: Integrate with VoiceAssist state so voice-reported hazards populate the real form and trigger existing `/api/analyze-hazard` and submission pipeline.
- `src/index.css`: Add styles for High Contrast mode (`.high-contrast`), Large Text mode (`.large-text`), and high-visibility focus rings.

---

### 5. Verification & Testing Plan

1. **Compilation & Lint**: Run `compile_applet` and `lint_applet` to ensure zero TypeScript errors.
2. **Web Speech Verification**: Test speech recognition and synthesis workflows across desktop and mobile browsers.
3. **Screen Reader & Keyboard Test**: Verify full tab sequence, `focus-visible` styling, escape key handlers, and ARIA live announcements.
4. **End-to-End Voice Submission**: Verify that a voice-guided hazard report creates a real incident in `CivicContext`, calculates priority, and appears in the Live Map and Accessible List.
